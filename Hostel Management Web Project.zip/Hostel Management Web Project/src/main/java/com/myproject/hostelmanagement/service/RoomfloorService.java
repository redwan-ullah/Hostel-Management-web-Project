/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Roomfloor;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RoomfloorService {
    public Roomfloor insertRoomfloor(Roomfloor bt);

    public void updateRoomfloor(Roomfloor bt);

    public void deleteRoomfloor(Integer id);

    public List<Roomfloor> viewRoomfloor();

    public Roomfloor viewOneRoomfloor(Integer id);
}
