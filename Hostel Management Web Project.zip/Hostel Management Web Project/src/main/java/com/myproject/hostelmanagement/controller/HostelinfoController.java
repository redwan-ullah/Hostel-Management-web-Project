/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.controller;

import com.myproject.hostelmanagement.model.Hostelinfo;
import com.myproject.hostelmanagement.service.HostelinfoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController
@RequestMapping(value = "/api/v1")
public class HostelinfoController {

    @Autowired
    private HostelinfoService hostelinfoService;

    @GetMapping("/hostelinfo")
    public List<Hostelinfo> getAllHostelinfo() {
        return hostelinfoService.viewHostelinfo();
    }

    @PostMapping("/hostelinfo")
    public Hostelinfo createHostelinfo(@RequestBody Hostelinfo hostelinfo) {
        return hostelinfoService.insertHostelinfo(hostelinfo);
    }

    @GetMapping("/hostelinfo/{id}")
    public ResponseEntity<Hostelinfo> getUser(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Hostelinfo hostelinfo = hostelinfoService.viewOneHostelinfo(id);
        if (hostelinfo == null) {
            System.out.println("Hostelinfo with id " + id + " not found");
            return new ResponseEntity<Hostelinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Hostelinfo>(hostelinfo, HttpStatus.OK);
    }

    @PutMapping("/hostelinfo/{id}")
    public ResponseEntity<Hostelinfo> updateHostelinfo(@PathVariable("id") Integer id, @RequestBody Hostelinfo hostelinfo) {
        System.out.println("Updating Hostelinfo " + id);

        Hostelinfo currentHostelinfo = hostelinfoService.viewOneHostelinfo(id);

        if (currentHostelinfo == null) {
            System.out.println("Hostelinfo with id " + id + " not found");
            return new ResponseEntity<Hostelinfo>(HttpStatus.NOT_FOUND);
        }

        currentHostelinfo.setHostid(hostelinfo.getHostid());
        currentHostelinfo.setAddress(hostelinfo.getAddress());
        currentHostelinfo.setHostname(hostelinfo.getHostname());
        

        hostelinfoService.updateHostelinfo(currentHostelinfo);
        return new ResponseEntity<Hostelinfo>(currentHostelinfo, HttpStatus.OK);
    }

    @DeleteMapping("/hostelinfo/{id}")
    public ResponseEntity<Hostelinfo> deleteHostelinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting Hostelinfo with id " + id);

        Hostelinfo hostelinfo = hostelinfoService.viewOneHostelinfo(id);
        if (hostelinfo == null) {
            System.out.println("Unable to delete. Hostelinfo with id " + id + " not found");
            return new ResponseEntity<Hostelinfo>(HttpStatus.NOT_FOUND);
        }

        hostelinfoService.deleteHostelinfo(id);
        return new ResponseEntity<Hostelinfo>(HttpStatus.NO_CONTENT);
    }

}
