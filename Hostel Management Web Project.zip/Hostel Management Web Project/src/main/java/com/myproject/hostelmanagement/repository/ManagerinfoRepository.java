/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.repository;

import com.myproject.hostelmanagement.model.Managerinfo;
import com.myproject.hostelmanagement.service.ManagerinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class ManagerinfoRepository implements ManagerinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Managerinfo insertManagerinfo(Managerinfo bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bt);
        t.commit();
        s.close();
        return bt;
    }

    @Override
    public void updateManagerinfo(Managerinfo bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bt);
        t.commit();
        s.close();
    }

    @Override
    public void deleteManagerinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Managerinfo bt = (Managerinfo) s.get(Managerinfo.class, id);
        s.delete(bt);
        t.commit();
        s.close();
    }

    @Override
    public List<Managerinfo> viewManagerinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Managerinfo> bustimetablelist = s.createQuery("from Managerinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return bustimetablelist;
    }

    @Override
    public Managerinfo viewOneManagerinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Managerinfo bt = (Managerinfo) s.get(Managerinfo.class, id);
        t.commit();
        s.close();
        return bt;
    }

   
    
}
