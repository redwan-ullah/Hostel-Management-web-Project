/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Roomallocation;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RoomallocationService {
    public Roomallocation insertRoomallocation(Roomallocation bt);

    public void updateRoomallocation(Roomallocation bt);

    public void deleteRoomallocation(Integer id);

    public List<Roomallocation> viewRoomallocation();

    public Roomallocation viewOneRoomallocation(Integer id);
}
