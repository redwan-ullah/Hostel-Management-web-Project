/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Notice;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface NoticeService {
    public Notice insertNotice(Notice bt);

    public void updateNotice(Notice bt);

    public void deleteNotice(Integer id);

    public List<Notice> viewNotice();

    public Notice viewOneNotice(Integer id);
}

