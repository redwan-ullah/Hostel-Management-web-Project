/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.repository;

import com.myproject.hostelmanagement.model.Hostelinfo;
import com.myproject.hostelmanagement.service.HostelinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class HostelinfoRepository implements HostelinfoService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Hostelinfo insertHostelinfo(Hostelinfo bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bt);
        t.commit();
        s.close();
        return bt;
    }

    @Override
    public void updateHostelinfo(Hostelinfo bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bt);
        t.commit();
        s.close();
    }

    @Override
    public void deleteHostelinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Hostelinfo bt = (Hostelinfo) s.get(Hostelinfo.class, id);
        s.delete(bt);
        t.commit();
        s.close();
    }

    @Override
    public List<Hostelinfo> viewHostelinfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Hostelinfo> bustimetablelist = s.createQuery("from Hostelinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return bustimetablelist;
    }

    @Override
    public Hostelinfo viewOneHostelinfo(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Hostelinfo bt = (Hostelinfo) s.get(Hostelinfo.class, id);
        t.commit();
        s.close();
        return bt;
    }

   
    
}
