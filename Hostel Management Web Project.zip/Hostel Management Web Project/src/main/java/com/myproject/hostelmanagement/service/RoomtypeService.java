/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Roomtype;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RoomtypeService {
    public Roomtype insertRoomtype(Roomtype bt);

    public void updateRoomtype(Roomtype bt);

    public void deleteRoomtype(Integer id);

    public List<Roomtype> viewRoomtype();

    public Roomtype viewOneRoomtype(Integer id);
}
