/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Managerinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface ManagerinfoService {
    public Managerinfo insertManagerinfo(Managerinfo bt);

    public void updateManagerinfo(Managerinfo bt);

    public void deleteManagerinfo(Integer id);

    public List<Managerinfo> viewManagerinfo();

    public Managerinfo viewOneManagerinfo(Integer id);
}
