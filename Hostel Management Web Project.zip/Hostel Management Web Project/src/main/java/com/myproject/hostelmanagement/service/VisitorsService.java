/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Visitors;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Visitors
 */
@Service
public interface VisitorsService {
    public Visitors insertVisitors(Visitors bt);

    public void updateVisitors(Visitors bt);

    public void deleteVisitors(Integer id);

    public List<Visitors> viewVisitors();

    public Visitors viewOneVisitors(Integer id);
}

