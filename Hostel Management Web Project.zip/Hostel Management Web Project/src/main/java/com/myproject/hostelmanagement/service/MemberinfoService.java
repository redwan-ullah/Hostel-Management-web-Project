/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Memberinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface MemberinfoService {
    public Memberinfo insertMemberinfo(Memberinfo bt);

    public void updateMemberinfo(Memberinfo bt);

    public void deleteMemberinfo(Integer id);

    public List<Memberinfo> viewMemberinfo();

    public Memberinfo viewOneMemberinfo(Integer id);
}
