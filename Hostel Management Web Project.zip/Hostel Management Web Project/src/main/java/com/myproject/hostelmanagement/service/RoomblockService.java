/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.hostelmanagement.service;


import com.myproject.hostelmanagement.model.Roomblock;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public interface RoomblockService {
    public Roomblock insertRoomblock(Roomblock bt);

    public void updateRoomblock(Roomblock bt);

    public void deleteRoomblock(Integer id);

    public List<Roomblock> viewRoomblock();

    public Roomblock viewOneRoomblock(Integer id);
}
